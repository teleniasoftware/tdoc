<?php

// Sorgente dati Customer Journey
$db_filename = "../db.json";

$tmp = file_get_contents($db_filename);
// Customer Journey del contatto
$customerJourney = json_decode($tmp, TRUE);

if (isset($_REQUEST)) {
	$agent = $_REQUEST['agent'];
	$dateTime = $_REQUEST['dateTime'];
	$callId = $_REQUEST['callId'];
	$callerNumber = $_REQUEST['callerNumber'];
	$service = $_REQUEST['service'];

	if (isset($callerNumber)) {
		if (isset($customerJourney[$callerNumber])) {
			$contact = $customerJourney[$callerNumber];
			$calls = $contact['calls'];
			$call = [
				'direction' => "IN"
			];

			if (isset($calls[$callId])) {
				$call = $calls[$callId];
			}

			$call['ringDateTime'] = $dateTime;
			$call['agent'] = $agent;
			$call['service'] = $service;

			$calls[$callId] = $call;
			$contact['calls'] = $calls;
			$customerJourney[$callerNumber] = $contact;
		}
	}
}

file_put_contents($db_filename, json_encode($customerJourney, JSON_PRETTY_PRINT));
