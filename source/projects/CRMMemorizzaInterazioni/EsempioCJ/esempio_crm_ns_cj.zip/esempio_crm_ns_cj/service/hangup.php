<?php

// Sorgente dati Customer Journey
$db_filename = "../db.json";

$tmp = file_get_contents($db_filename);
// Customer Journey del contatto
$customerJourney = json_decode($tmp, TRUE);

if (isset($_REQUEST)) {
	$dateTime = $_REQUEST['dateTime'];
	$callId = $_REQUEST['callId'];
	$callerNumber = $_REQUEST['callerNumber'];

	if (isset($callerNumber)) {
		if (isset($customerJourney[$callerNumber])) {
			$contact = $customerJourney[$callerNumber];
			$calls = $contact['calls'];

			if (isset($calls[$callId])) {
				$call = $calls[$callId];
				if (!isset($call['transferToDateTime']) && !isset($call['transferToAnswerDateTime'])) {
					$call['hangupDateTime'] = $dateTime;
				} else {
					$call['hangupDateTime'] = $call['transferToDateTime'];
					$call['transferToHangupDateTime'] = $dateTime;
				}

				$calls[$callId] = $call;
				$contact['calls'] = $calls;
				$customerJourney[$callerNumber] = $contact;
			}
		}
	}
}

file_put_contents($db_filename, json_encode($customerJourney, JSON_PRETTY_PRINT));
