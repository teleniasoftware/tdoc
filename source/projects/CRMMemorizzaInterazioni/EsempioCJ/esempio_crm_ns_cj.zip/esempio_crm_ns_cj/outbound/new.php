<?php

// Sorgente dati Customer Journey
$db_filename = "../db.json";

$tmp = file_get_contents($db_filename);
// Customer Journey del contatto
$customerJourney = json_decode($tmp, TRUE);

if (isset($_REQUEST)) {
	$agent = $_REQUEST['agent'];
	$dateTime = $_REQUEST['dateTime'];
	$callId = $_REQUEST['callId'];
	$calledNumber = $_REQUEST['calledNumber'];

	if (isset($calledNumber)) {
		if (isset($customerJourney[$calledNumber])) {
			$contact = $customerJourney[$calledNumber];
			$calls = $contact['calls'];
			$call = [
				'direction' => "OUT"
			];
			
			if (isset($calls[$callId])) {
				$call = $calls[$callId];
			}
			
			$call['newDateTime'] = $dateTime;
			$call['agent'] = $agent;
			
			$calls[$callId] = $call;
			$contact['calls'] = $calls;
			$customerJourney[$calledNumber] = $contact;
		}
	}
}

file_put_contents($db_filename, json_encode($customerJourney, JSON_PRETTY_PRINT));
