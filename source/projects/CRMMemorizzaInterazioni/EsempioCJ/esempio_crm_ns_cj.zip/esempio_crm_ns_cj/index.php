<!DOCTYPE html>
<?php

// Sorgente dati Customer Journey
$db_filename = "db.json";

// Numero / Chiave del contatto Mario Rossi
$contactKey = "0987654321";

if (file_exists($db_filename)) {
	$tmp = file_get_contents($db_filename);
	// Customer Journey del contatto
	$customerJourney = json_decode($tmp, TRUE);
}

// Mappa tipo chiamata
$typeMap = [
	'IN' => "Chiamata di Servizio Inbound",
	'OUT' => "Chiamata Outbound"
];

// Mappa operatori
$agentsMap = [
	'op1' => "Operatore 1",
	'op2' => "Operatore 2"
];

// Mappa servizi
$servicesMap = [
	'customercare' => 'Customer Care'
];

// Reset Customer Journey
if (isset($_POST['resetCJ'])) {
	if (isset($customerJourney[$contactKey])) {
		$customerJourney[$contactKey]['calls'] = [];
		file_put_contents($db_filename, json_encode($customerJourney, JSON_PRETTY_PRINT));
		header("location: /index.php");
	}
}

?>

<html>

<head>
	<style>
		table {
			font-family: arial, sans-serif;
			border-collapse: collapse;
			width: 100%;
		}

		td,
		th {
			border: 1px solid #dddddd;
			text-align: left;
			padding: 8px;
		}

		tr:nth-child(even) {
			background-color: #dddddd;
		}
	</style>
</head>

<body>
	<fieldset style="text-align: center;">
		<?php if (isset($customerJourney) && isset($customerJourney[$contactKey])) {
			// Customer Journey del contatto
			$contact = $customerJourney[$contactKey];
			// Chiamate del contatto
			$calls = array_reverse($contact['calls']);
		?>
			<h1><?php echo $contact['surname'] . " " . $contact['name'] ?></h1>
			<h3>Telefono: <?php echo $contactKey; ?></h3>
	</fieldset>
	<fieldset style="margin-top: 10px;">
		<form method="post">
			<input type="hidden" id="resetCJ" name="resetCJ" value="true">
			<button style="float: right; margin-bottom: 10px;">Cancella Journey</button>
		</form>
		<table>
			<thead>
				<tr>
					<th>Tipo</th>
					<th>Servizio</th>
					<th>Operatore</th>
					<th>Data/Ora inizio</th>
					<th>Data/Ora risposta</th>
					<th>Data/Ora fine</th>
					<th>Altro</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($calls as $callId => $call) { ?>
					<tr>
						<td> <?php echo $typeMap[$call['direction']]; ?></td>
						<td><?php echo isset($call['service']) ? $servicesMap[$call['service']] : "-"; ?></td>
						<td><?php echo $agentsMap[$call['agent']]; ?></td>
						<td><?php echo $call['direction'] === "IN" ? date("d-m-Y H:i:s", strtotime($call['ringDateTime'])) : date("d-m-Y H:i:s", strtotime($call['newDateTime'])); ?></td>
						<td><?php echo isset($call['answerDateTime']) ? date("d-m-Y H:i:s", strtotime($call['answerDateTime'])) : "-"; ?></td>
						<td><?php echo isset($call['hangupDateTime']) ? date("d-m-Y H:i:s", strtotime($call['hangupDateTime'])) : "-"; ?></td>
						<td>
							<?php
							if ($call['direction'] === "IN" && isset($call['transferToDateTime'])) {
								if ($call['transferToDateTime'] == $call['transferToAnswerDateTime']) {
									echo "<b>Chiamata trasferita (con consultazione)</b><br>";
								} else {
									echo "<b>Chiamata trasferita (diretta / blind)</b><br>";
								}
								echo "<ul>";
								echo "<li><i>Data/Ora trasferta:</i> " . date("d-m-Y H:i:s", strtotime($call['transferToDateTime'])) . "</li>";
								echo "<li><i>Trasferita ad operatore:</i> " . $agentsMap[$call['transferToAgent']] . "</li>";
								echo "<li><i>Data/Ora fine:</i> " . (isset($call['transferToHangupDateTime']) ? date("d-m-Y H:i:s", strtotime($call['transferToHangupDateTime']))  : "-") . "</li>";
								echo "</ul>";
							}
							?>
						</td>
					</tr>
				<?php } ?>
			</tbody>
		</table>
	</fieldset>
<?php } else { ?>
	<h1>Il contatto non è stato trovato</h1>
	<h3>Verificare la sorgente dati</h3>
	(controllare che sia presente il file <i>db.json</i> e che al suo interno esista il contatto)
<?php } ?>
</body>

</html>