<?php

$this->info("Start script esercizio_corso_tts_asr.php");
global $voiceConfiguration, $maxRetry, $clid, $dnis;

$clid = $this->Agi->request["agi_callerid"];
$dnis = $this->Serv->Exten;
$maxRetry = 3;

$voiceConfiguration = array(
    "profile" => "google_cloud_service",
    "language" => "it-IT",
    "gender" => "female"
);

$lookupResult = $this->externalLookup($clid);

if (isset($lookupResult)) {
    playContactFile($this, $lookupResult);
}

$tipoAssenza = selezionaTipologiaAssenza($this);
$this->info("Tipologia assenza: $tipoAssenza");


$fileName = null;
switch ($tipoAssenza) {
    case "malattia":
        $fileName = "messaggio_malattia";
        break;
    case "infortunio":
        $fileName = "messaggio_infortunio";
        break;
}
registraAudio($this, $fileName);

$fileName = "messaggio_dissuasione";
$res = $this->Ivr_play(array($fileName, 0));
if ($res[0] == TVOX_IVR_CALLER_EXIT) {
    $this->info("exit - user hangup on $fileName");
    $this->RightExitIVR();
}

$this->RightExitIVR();


$this->info("End script esercizio_corso_tts_asr.php");

function playContactFile($ivr, $lookupResult) {
    global $voiceConfiguration;
    $contactName = $lookupResult[0][VCardProperties::FN][0]["value"][0][0];
    $ivr->info("Il nome del contatto �: $contactName");

    if (isset($contactName) && !empty($contactName)) {
        $options = array_merge(array("text" => "Buongiorno $contactName"), $voiceConfiguration);
        $res = $ivr->Ivr_speech_synthesize($options);
        if ($res[0] == TVOX_IVR_CALLER_EXIT || $res[0] == TVOX_IVR_FORCED_EXIT || $res[0] == TVOX_IVR_ERROR) {
            $this->info("exit - user hanghup on synthetize");
            $ivr->RightExitIVR();
        }
    }
}

function selezionaTipologiaAssenza($ivr) {
    global $voiceConfiguration, $maxRetry;
    $grammar = dirname(__FILE__) . "/service_grammar.grxml";
    $fileName = $ivr->getSoundPath() . "ivr/messaggio_selezione_assenza";
    $options = array_merge(array("file" => $fileName, "grammar" => $grammar), $voiceConfiguration);

    for ($i = 0; $i < $maxRetry; $i++) {
        $res = $ivr->Ivr_speech_recognition($options);
        if ($res[0] == TVOX_IVR_CALLER_EXIT) {
            $ivr->info("exit - user hangup on asr recognition");
            $ivr->RightExitIVR();
        }

        $resultRecognition = $ivr->Agi->get_variable(TVOX_RECOG_RESULT);
        if ($resultRecognition["code"] == AGIRES_OK) {
            if ($resultRecognition["data"] == TVOX_RECOG_RESULT_OK) {
                $type = $ivr->Agi->get_variable(TVOX_RECOG_DATA);
                return $type["data"];
            }
        } else {
            $ivr->info("exit - user hangup on speech recognition");
            $ivr->RightExitIVR();
        }
    }
    return null;
}

function registraAudio($ivr, $fileName = null) {
    global $clid, $dnis;
    if (!isset($fileName)) {
        $fileName = "messaggio_assenza_generico";
    }

    $res = $ivr->Ivr_play(array($fileName, 0));
    if ($res[0] == TVOX_IVR_CALLER_EXIT) {
        $ivr->info("exit - user hangup on filename recording");
        $ivr->RightExitIVR();
    }

    $res = $ivr->Ivr_play(array("beep-09", 0));
    if ($res[0] == TVOX_IVR_CALLER_EXIT) {
        $ivr->info("exit - user hangup on beep-09");
        $ivr->RightExitIVR();
    }

    $digits = array("#");


    $fileRec = $ivr->Ivr_start_rec($clid, $dnis, "I", true, true);

    $res = $ivr->Ivr_choose_option(array("", $digits, NULL, 60));
    if ($res[0] == TVOX_IVR_CALLER_EXIT) {
        $ivr->info("exit - user hangup on choose option");
        $ivr->RightExitIVR();
    }

    $ivr->Ivr_stop_rec(null, true);
    $ivr->info("Audio registrato e salvato con il nome di $fileRec");
}
