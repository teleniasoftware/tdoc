<?php
error_reporting(E_ALL);
$this->info("start esercizio_videocorso.php");

define("CODICE_CLIENTE", "CODICE_CLIENTE");

global $maxRetry, $timeoutDigit, $databaseHost, $databaseUsername, $databasePassword, $databaseName;

$maxRetry = 3;
$timeoutDigit = 5;

$databaseHost = "172.16.94.86";
$databaseUsername= "test";
$databasePassword = "test";
$databaseName = "test";

$codiceServizio = "serviziocorso00001";

$fileName = "messaggio_benvenuto";
$result = $this->Ivr_play(array($fileName, 0));
if($result[0] == TVOX_IVR_CALLER_EXIT){
    $this->info("exit hangup on $fileName");
    $this->RightExitIVR();
}

$codiceClienteInserito = inserisciCodiceCliente($this);

if($codiceClienteInserito){
    goToService($this, $codiceServizio);
} else {
    $fileName = "messaggio_dissuasione";
    $result = $this->Ivr_play(array($fileName, 0));
    if($result[0] == TVOX_IVR_CALLER_EXIT){
        $this->info("exit hangup on $fileName");
        $this->RightExitIVR();
    }
}


$this->RightExitIVR();


$this->info("end esercizio_videocorso.php");

function goToService($ivr, $codiceServizio){
    $ivr->info("service to load $codiceServizio");
    $ivr->Ivr_load_serv(array($codiceServizio));
    $ivr->RightExitIVR();
}


function inserisciCodiceCliente($ivr){
    global $maxRetry;
    
    for($i = 0; $i < $maxRetry; $i++){
        $codiceCliente = recuperaCodiceCliente($ivr);
        $codiceInseritoConfermato = ripetiCodiceCliente($ivr);
        if($codiceInseritoConfermato){
            $codiceValido = validaCodiceCliente($ivr, $codiceCliente);
            if($codiceValido){
                return true;
            } else {
                $fileName = "codice_non_valido";
                $result = $ivr->Ivr_play(array($fileName, 0));
                if($result[0] == TVOX_IVR_CALLER_EXIT){
                    $ivr->info("exit hangup on $fileName");
                    $ivr->RightExitIVR();
                }
                continue;
            }
        } else {
            continue;
        }
    }
    return false;
}

function validaCodiceCliente($ivr, $codiceCliente){
    global $databaseHost, $databaseUsername, $databasePassword, $databaseName;
    
    $conn = new mysqli($databaseHost, $databaseUsername, $databasePassword, $databaseName);
    
    if($conn->connect_error){
        $ivr->info("Error connect to database");
        $ivr->sendAlarm(4, "Database non raggiungibile");
    }
    
    $sql = "SELECT * FROM anagrafica WHERE codice_cliente = $codiceCliente";
    
    $result = $conn->query($sql);
    $nr = $result->num_rows;
    if($nr > 0){
        return true;
    }
    
    return false;
}

function ripetiCodiceCliente($ivr){
    $fileName = "ripeti_codice";
    $result = $ivr->Ivr_play(array($fileName, 0));
    if($result[0] == TVOX_IVR_CALLER_EXIT){
        $ivr->info("exit hangup on $fileName");
        $ivr->RightExitIVR();
    }
    
    $result = $ivr->Ivr_saysaved(array(CODICE_CLIENTE));
    if ($res[0] == TVOX_IVR_CALLER_EXIT) {
        $ivr->debug("exit - error say digits");
        $ivr->RightExitIVR();
    }
    
    $codiceInseritoConfermato = confermaCodiceInserito($ivr);
    return $codiceInseritoConfermato;
}

function confermaCodiceInserito($ivr){
    global $timeoutDigit;
    $ivr->lastDigit = null;
    $fileName = "digita_conferma_codice";
    $result = $ivr->Ivr_choose_option(array($fileName, array(1,2), null, $timeoutDigit));
    if($result[0] == TVOX_IVR_CALLER_EXIT){
        $ivr->info("exit confermaCodiceInserito - hangup on $fileName");
        $ivr->RightExitIVR();
    }
    
    $resultDigit = false;
    if(isset($ivr->lastDigit) && $ivr->lastDigit != ""){
        switch($ivr->lastDigit){
            case "1":
                $resultDigit = true;
                break;
            case "2":
                $resultDigit = false;
                break;
        }   
    }
    
    return $resultDigit;
}

function recuperaCodiceCliente($ivr){
    global $timeoutDigit;
    $ivr->Ivr_setvar(array(CODICE_CLIENTE, ""));
    $fileName = "inserimento_codice_cliente";
    $result = $ivr->Ivr_get_digit(array($fileName, 6, CODICE_CLIENTE, $timeoutDigit));
    if($result[0] == TVOX_IVR_CALLER_EXIT){
        $ivr->info("exit recuperaCodiceCliente - user hangup on $fileName");
        $ivr->RightExitIVR();
    }
    $codiceCliente = $ivr->Ivr_getvar(array(CODICE_CLIENTE));
    return $codiceCliente;
}



